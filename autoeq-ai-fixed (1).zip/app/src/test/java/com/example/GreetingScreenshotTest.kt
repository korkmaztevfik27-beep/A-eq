package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.components.ControlPanel
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        ControlPanel(
          isPlaying = false,
          currentPositionMs = 3000L,
          durationMs = 12000L,
          volume = 0.8f,
          isMuted = false,
          isEqActive = true,
          isShuffle = false,
          isRepeat = false,
          onTogglePlayPause = {},
          onPlayPrevious = {},
          onPlayNext = {},
          onSeekTo = {},
          onSetVolume = {},
          onToggleMute = {},
          onToggleEq = {},
          onToggleShuffle = {},
          onToggleRepeat = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
