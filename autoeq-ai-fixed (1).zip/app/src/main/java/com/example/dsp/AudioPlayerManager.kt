package com.example.dsp

import android.content.Context
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import android.media.audiofx.PresetReverb
import android.net.Uri
import android.util.Log
import com.example.data.AnalyzedTrack
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.FileInputStream
import kotlin.math.max
import kotlin.math.pow

class AudioPlayerManager(private val context: Context) {
    private val TAG = "AudioPlayerManager"

    private var mediaPlayer: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var presetReverb: PresetReverb? = null

    // Playback state variables
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    private val _volume = MutableStateFlow(1.0f)
    val volume: StateFlow<Float> = _volume

    private val _isEqActive = MutableStateFlow(true)
    val isEqActive: StateFlow<Boolean> = _isEqActive

    // Extra dynamic DSP audio effects
    private val _bassBoostStrength = MutableStateFlow(0) // 0 to 1000
    val bassBoostStrength: StateFlow<Int> = _bassBoostStrength

    private val _virtualizerStrength = MutableStateFlow(0) // 0 to 1000
    val virtualizerStrength: StateFlow<Int> = _virtualizerStrength

    private val _reverbPresetIdx = MutableStateFlow(0) // 0 = None, 1 = Small Room, 2 = Medium Room, 3 = Large Room, 4 = Medium Hall, 5 = Large Hall, 6 = Plate
    val reverbPresetIdx: StateFlow<Int> = _reverbPresetIdx

    // Dynamic Playback Speed (0.5x - 2.0x)
    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed

    // Pre-Amp Gain Boost (0 dB to +12 dB)
    private val _preAmpGain = MutableStateFlow(0.0f)
    val preAmpGain: StateFlow<Float> = _preAmpGain

    // Sleep Timer (seconds remaining, null when inactive)
    private var sleepTimerJob: Job? = null
    private val _sleepTimerSecondsLeft = MutableStateFlow<Long?>(null)
    val sleepTimerSecondsLeft: StateFlow<Long?> = _sleepTimerSecondsLeft

    // Active EQ Preset name
    private val _activePreset = MutableStateFlow("AI Auto Master")
    val activePreset: StateFlow<String> = _activePreset

    private val _currentTrack = MutableStateFlow<AnalyzedTrack?>(null)
    val currentTrack: StateFlow<AnalyzedTrack?> = _currentTrack

    // Track state of playlist
    private var playlist: List<AnalyzedTrack> = emptyList()
    private var currentIndex = -1

    private var isShuffle = false
    private var isRepeat = false

    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var positionJob: Job? = null

    // Manual fine-tune gains corresponding to the 29 bands (stored relative to the AI defaults)
    private val _manualGains = MutableStateFlow<FloatArray>(FloatArray(AudioAnalyzer.EQ_FREQUENCIES.size))
    val manualGains: StateFlow<FloatArray> = _manualGains

    fun setPlaylist(tracks: List<AnalyzedTrack>, startIndex: Int, autoPlay: Boolean = true) {
        playlist = tracks
        currentIndex = startIndex
        if (tracks.isNotEmpty() && startIndex in tracks.indices) {
            if (autoPlay) {
                playTrack(tracks[startIndex])
            } else {
                setTrackSilently(tracks[startIndex])
            }
        }
    }

    fun updatePlaylistPreservingPlayback(tracks: List<AnalyzedTrack>, newIndex: Int) {
        playlist = tracks
        currentIndex = newIndex
    }

    fun setTrackSilently(track: AnalyzedTrack) {
        _currentTrack.value = track
        _duration.value = track.durationMs
        _manualGains.value = FloatArray(AudioAnalyzer.EQ_FREQUENCIES.size)
    }

    fun togglePlayPause() {
        val player = mediaPlayer
        if (player == null) {
            val track = _currentTrack.value ?: playlist.firstOrNull()
            if (track != null) {
                playTrack(track)
            }
            return
        }
        try {
            if (player.isPlaying) {
                player.pause()
                _isPlaying.value = false
                stopPositionTracking()
            } else {
                player.start()
                _isPlaying.value = true
                startPositionTracking()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling play/pause: ${e.message}")
            val track = _currentTrack.value ?: playlist.firstOrNull()
            if (track != null) {
                playTrack(track)
            }
        }
    }

    private fun configureDataSource(player: MediaPlayer, uriString: String) {
        val uri = Uri.parse(uriString)
        if (uri.scheme == "file" || uri.scheme == null) {
            val path = uri.path ?: uriString
            val file = File(path)
            if (file.exists()) {
                java.io.FileInputStream(file).use { fis ->
                    player.setDataSource(fis.fd)
                }
                return
            }
        }
        // If content:// or file in SAF
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                player.setDataSource(pfd.fileDescriptor)
                return
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed getting fd from ContentResolver: ${e.message}")
        }
        player.setDataSource(context, uri)
    }

    fun playTrack(track: AnalyzedTrack) {
        stopPlayback()
        _currentTrack.value = track
        _duration.value = track.durationMs

        // Reset custom fine-tune gains to neutral for the new track
        _manualGains.value = FloatArray(AudioAnalyzer.EQ_FREQUENCIES.size)
        _activePreset.value = "AI Auto Master"

        try {
            mediaPlayer = MediaPlayer().apply {
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error occurred: what=$what, extra=$extra")
                    _isPlaying.value = false
                    stopPositionTracking()
                    true
                }
                configureDataSource(this, track.uriString)
                prepare()

                if (_playbackSpeed.value != 1.0f) {
                    try {
                        val params = playbackParams
                        params.speed = _playbackSpeed.value
                        playbackParams = params
                    } catch (e: Exception) {
                        Log.w(TAG, "Speed set non-fatal: ${e.message}")
                    }
                }

                start()
                setOnCompletionListener {
                    handleTrackCompletion()
                }
            }
            _isPlaying.value = true

            // Set up hardware EQ DSP safely
            try {
                initEqualizer()
                applyEq()
            } catch (e: Exception) {
                Log.w(TAG, "Equalizer setup non-fatal: ${e.message}")
            }

            // Set up physical spatial & ambient dynamic effects safely
            try {
                initExtraEffects()
            } catch (e: Exception) {
                Log.w(TAG, "DSP effects setup non-fatal: ${e.message}")
            }

            // Apply volume & mute
            try {
                applyVolume()
            } catch (e: Exception) {
                Log.w(TAG, "Volume apply non-fatal: ${e.message}")
            }

            startPositionTracking()
            Log.d(TAG, "Playing track: ${track.title} by ${track.artist}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to play track: ${e.message}", e)
            _isPlaying.value = false
        }
    }

    fun stopPlayback() {
        stopPositionTracking()
        _isPlaying.value = false
        _currentPosition.value = 0L

        try {
            equalizer?.release()
            equalizer = null
            bassBoost?.release()
            bassBoost = null
            virtualizer?.release()
            virtualizer = null
            presetReverb?.release()
            presetReverb = null
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping playback: ${e.message}")
        }
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let {
            it.seekTo(positionMs.toInt())
            _currentPosition.value = positionMs
        }
    }

    fun setVolume(vol: Float) {
        _volume.value = vol.coerceIn(0f, 1f)
        applyVolume()
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        applyVolume()
    }

    fun toggleEq() {
        _isEqActive.value = !_isEqActive.value
        applyEq()
    }

    fun toggleShuffle(active: Boolean) {
        isShuffle = active
    }

    fun toggleRepeat(active: Boolean) {
        isRepeat = active
    }

    fun updateManualGain(bandIndex: Int, newGain: Float) {
        val current = _manualGains.value.clone()
        if (bandIndex in current.indices) {
            current[bandIndex] = newGain.coerceIn(-12f, 12f)
            _manualGains.value = current
            applyEq()
        }
    }

    fun playNext() {
        if (playlist.isEmpty()) return
        if (isRepeat) {
            _currentTrack.value?.let { playTrack(it) }
            return
        }

        if (isShuffle) {
            currentIndex = playlist.indices.random()
        } else {
            currentIndex = (currentIndex + 1) % playlist.size
        }
        playTrack(playlist[currentIndex])
    }

    fun playPrevious() {
        if (playlist.isEmpty()) return
        if (isRepeat) {
            _currentTrack.value?.let { playTrack(it) }
            return
        }

        currentIndex = if (currentIndex - 1 < 0) {
            playlist.size - 1
        } else {
            currentIndex - 1
        }
        playTrack(playlist[currentIndex])
    }

    private fun handleTrackCompletion() {
        if (isRepeat) {
            _currentTrack.value?.let { playTrack(it) }
        } else {
            playNext()
        }
    }

    private fun initEqualizer() {
        val player = mediaPlayer ?: return
        try {
            equalizer?.release()
            // Create equalizer bound to the audio session of the active MediaPlayer
            equalizer = Equalizer(0, player.audioSessionId).apply {
                enabled = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize hardware Equalizer: ${e.message}")
            equalizer = null
        }
    }

    private fun initExtraEffects() {
        val player = mediaPlayer ?: return
        try {
            bassBoost?.release()
            bassBoost = BassBoost(0, player.audioSessionId).apply {
                enabled = true
                setStrength(_bassBoostStrength.value.toShort())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize BassBoost: ${e.message}")
            bassBoost = null
        }

        try {
            virtualizer?.release()
            virtualizer = Virtualizer(0, player.audioSessionId).apply {
                enabled = true
                setStrength(_virtualizerStrength.value.toShort())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Virtualizer: ${e.message}")
            virtualizer = null
        }

        try {
            presetReverb?.release()
            presetReverb = PresetReverb(0, 0).apply {
                enabled = true
                preset = mapPresetIndexToHardwareVal(_reverbPresetIdx.value)
            }
            if (_reverbPresetIdx.value > 0) {
                try {
                    player.attachAuxEffect(presetReverb?.id ?: 0)
                    player.setAuxEffectSendLevel(1.0f)
                } catch (e: Exception) {
                    Log.w(TAG, "Aux effect attach ignored: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to initialize PresetReverb: ${e.message}")
            presetReverb = null
        }
    }

    private fun mapPresetIndexToHardwareVal(idx: Int): Short {
        return when (idx) {
            1 -> PresetReverb.PRESET_SMALLROOM
            2 -> PresetReverb.PRESET_MEDIUMROOM
            3 -> PresetReverb.PRESET_LARGEROOM
            4 -> PresetReverb.PRESET_MEDIUMHALL
            5 -> PresetReverb.PRESET_LARGEHALL
            6 -> PresetReverb.PRESET_PLATE
            else -> PresetReverb.PRESET_NONE
        }
    }

    fun setBassBoostStrength(strength: Int) {
        val safe = strength.coerceIn(0, 1000)
        _bassBoostStrength.value = safe
        try {
            bassBoost?.setStrength(safe.toShort())
        } catch (e: Exception) {
            Log.e(TAG, "Failed setting BassBoost strength: ${e.message}")
        }
    }

    fun setVirtualizerStrength(strength: Int) {
        val safe = strength.coerceIn(0, 1000)
        _virtualizerStrength.value = safe
        try {
            virtualizer?.setStrength(safe.toShort())
        } catch (e: Exception) {
            Log.e(TAG, "Failed setting Virtualizer strength: ${e.message}")
        }
    }

    fun setReverbPreset(presetIdx: Int) {
        val safe = presetIdx.coerceIn(0, 6)
        _reverbPresetIdx.value = safe
        try {
            presetReverb?.preset = mapPresetIndexToHardwareVal(safe)
        } catch (e: Exception) {
            Log.e(TAG, "Failed setting Reverb preset: ${e.message}")
        }
    }

    private fun applyVolume() {
        val player = mediaPlayer ?: return
        val finalVolume = if (_isMuted.value) 0.0f else _volume.value

        // Safe DSP Leveling & Pre-Amp Gain
        val eqCompensation = getSafeDspGainCompensationFactor()
        val preAmpMultiplier = 10.0f.pow(_preAmpGain.value / 20.0f)
        val compensatedVolume = (finalVolume * eqCompensation * preAmpMultiplier).coerceIn(0.0f, 1.0f)

        player.setVolume(compensatedVolume, compensatedVolume)
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 2.5f)
        _playbackSpeed.value = clamped
        try {
            mediaPlayer?.let { player ->
                val params = player.playbackParams
                params.speed = clamped
                player.playbackParams = params
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed setting playback speed: ${e.message}")
        }
    }

    fun setPreAmpGain(gainDb: Float) {
        _preAmpGain.value = gainDb.coerceIn(0.0f, 12.0f)
        applyVolume()
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerSecondsLeft.value = null
            return
        }
        val totalSeconds = minutes * 60L
        _sleepTimerSecondsLeft.value = totalSeconds
        sleepTimerJob = coroutineScope.launch {
            var remaining = totalSeconds
            while (remaining > 0 && isActive) {
                delay(1000)
                remaining--
                _sleepTimerSecondsLeft.value = remaining
            }
            if (remaining <= 0) {
                _sleepTimerSecondsLeft.value = null
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        player.pause()
                        _isPlaying.value = false
                        stopPositionTracking()
                    }
                }
            }
        }
    }

    fun seekBy(deltaMs: Long) {
        val newPos = (_currentPosition.value + deltaMs).coerceIn(0L, _duration.value)
        seekTo(newPos)
    }

    fun applyPreset(presetName: String) {
        val gains = FloatArray(AudioAnalyzer.EQ_FREQUENCIES.size)
        when (presetName) {
            "Bass Boost" -> {
                for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                    val f = AudioAnalyzer.EQ_FREQUENCIES[i]
                    gains[i] = when {
                        f <= 60f -> 5.5f
                        f <= 120f -> 4.0f
                        f <= 250f -> 2.0f
                        f >= 10000f -> 1.5f
                        else -> 0f
                    }
                }
            }
            "Vocal Clarity" -> {
                for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                    val f = AudioAnalyzer.EQ_FREQUENCIES[i]
                    gains[i] = when {
                        f < 100f -> -2.5f
                        f in 200f..400f -> -1.5f
                        f in 1000f..4000f -> 3.5f
                        f in 4000f..8000f -> 2.0f
                        else -> 0f
                    }
                }
            }
            "Electronic / EDM" -> {
                for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                    val f = AudioAnalyzer.EQ_FREQUENCIES[i]
                    gains[i] = when {
                        f <= 80f -> 5.0f
                        f in 200f..400f -> -1.5f
                        f in 1000f..2500f -> 1.0f
                        f >= 8000f -> 3.5f
                        else -> 0f
                    }
                }
            }
            "Rock & Metal" -> {
                for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                    val f = AudioAnalyzer.EQ_FREQUENCIES[i]
                    gains[i] = when {
                        f in 60f..160f -> 3.5f
                        f in 500f..1250f -> -2.0f
                        f in 2500f..6300f -> 3.5f
                        f >= 10000f -> 2.0f
                        else -> 0f
                    }
                }
            }
            "Acoustic / Warm" -> {
                for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                    val f = AudioAnalyzer.EQ_FREQUENCIES[i]
                    gains[i] = when {
                        f in 160f..500f -> 2.5f
                        f in 1000f..3150f -> 1.5f
                        f > 12000f -> -1.5f
                        else -> 0.5f
                    }
                }
            }
            "Podcast / Voice" -> {
                for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                    val f = AudioAnalyzer.EQ_FREQUENCIES[i]
                    gains[i] = when {
                        f < 100f -> -5.0f
                        f in 1500f..4000f -> 3.5f
                        f in 5000f..8000f -> -2.0f
                        else -> 0f
                    }
                }
            }
            "Flat / Bypass" -> {
                // All 0.0f
            }
            else -> {
                // "AI Auto Master" - neutral fine-tuning, applies track's deep spectral gains
            }
        }
        _activePreset.value = presetName
        _manualGains.value = gains
        applyEq()
    }

    fun resetManualGains() {
        applyPreset("AI Auto Master")
    }

    private fun getSafeDspGainCompensationFactor(): Float {
        if (!_isEqActive.value) return 1.0f

        val track = _currentTrack.value ?: return 1.0f
        val aiGains = getAiGains(track)
        val fineGains = _manualGains.value

        var maxBoost = 0.0f
        var averageBoost = 0.0f
        var activeCount = 0

        for (i in aiGains.indices) {
            val totalGain = aiGains[i] + (fineGains.getOrNull(i) ?: 0f)
            if (totalGain > 0f) {
                maxBoost = max(maxBoost, totalGain)
                averageBoost += totalGain
                activeCount++
            }
        }

        if (activeCount > 0) {
            averageBoost /= activeCount
        }

        // Auto Gain Compensation: Reduce overall player master output by equivalent amount of boosts
        // Formulated mathematically to maintain perceived energy while avoiding digital headroom clipping
        val dbReduction = max(0.0f, (averageBoost * 0.5f) + (maxBoost * 0.3f))
        return 10.0f.pow(-dbReduction / 20.0f)
    }

    fun getAiGains(track: AnalyzedTrack): FloatArray {
        return try {
            track.eqBandsGainsCsv.split(",").map { it.toFloat() }.toFloatArray()
        } catch (e: Exception) {
            FloatArray(AudioAnalyzer.EQ_FREQUENCIES.size)
        }
    }

    fun getCombinedGains(track: AnalyzedTrack): FloatArray {
        val aiGains = getAiGains(track)
        val fineGains = _manualGains.value
        val combined = FloatArray(AudioAnalyzer.EQ_FREQUENCIES.size)
        for (i in combined.indices) {
            val total = aiGains[i] + (fineGains.getOrNull(i) ?: 0f)
            combined[i] = total.coerceIn(-12f, 12f)
        }
        return combined
    }

    private fun applyEq() {
        val eq = equalizer ?: return
        val track = _currentTrack.value ?: return

        try {
            eq.enabled = _isEqActive.value

            if (_isEqActive.value) {
                val combinedGains = getCombinedGains(track)
                val numBands = eq.numberOfBands.toInt()
                val minLevel = eq.bandLevelRange[0] // Typically -1500 (-15dB)
                val maxLevel = eq.bandLevelRange[1] // Typically 1500 (+15dB)

                for (band in 0 until numBands) {
                    val centerFreqHz = eq.getCenterFreq(band.toShort()) / 1000f // Convert mHz to Hz

                    // Find nearest frequency index in our 29 EQ bands list
                    var nearestIdx = 0
                    var minDistance = Float.MAX_VALUE
                    for (i in AudioAnalyzer.EQ_FREQUENCIES.indices) {
                        val distance = kotlin.math.abs(AudioAnalyzer.EQ_FREQUENCIES[i] - centerFreqHz)
                        if (distance < minDistance) {
                            minDistance = distance
                            nearestIdx = i
                        }
                    }

                    val rawDbGain = combinedGains[nearestIdx]
                    // Convert dB to millibels (1dB = 100mB)
                    val mBLevel = (rawDbGain * 100).toInt().coerceIn(minLevel.toInt(), maxLevel.toInt())
                    eq.setBandLevel(band.toShort(), mBLevel.toShort())
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed applying settings on hardware equalizer: ${e.message}")
        }

        // Adjust master volume to account for new gain offsets (Safe DSP clipping prevention)
        applyVolume()
    }

    private fun startPositionTracking() {
        positionJob?.cancel()
        positionJob = coroutineScope.launch {
            while (isActive) {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        _currentPosition.value = it.currentPosition.toLong()
                    }
                }
                delay(250)
            }
        }
    }

    private fun stopPositionTracking() {
        positionJob?.cancel()
        positionJob = null
    }

    fun release() {
        coroutineScope.cancel()
        stopPlayback()
    }
}
