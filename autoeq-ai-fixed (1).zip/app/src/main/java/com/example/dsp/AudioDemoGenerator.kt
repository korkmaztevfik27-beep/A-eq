package com.example.dsp

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object AudioDemoGenerator {
    private const val TAG = "AudioDemoGenerator"
    private const val SAMPLE_RATE = 44100
    private const val DURATION_SECONDS = 12

    suspend fun generateDemoAudio(context: Context): Uri = withContext(Dispatchers.IO) {
        val cacheDir = File(context.cacheDir, "dsp_tracks")
        if (!cacheDir.exists()) cacheDir.mkdirs()

        val demoFile = File(cacheDir, "demo_master_synthwave.wav")
        if (demoFile.exists() && demoFile.length() > 100000) {
            return@withContext Uri.fromFile(demoFile)
        }

        try {
            val totalSamples = SAMPLE_RATE * DURATION_SECONDS
            val numChannels = 2 // Stereo
            val bytesPerSample = 2 // 16-bit
            val dataSize = totalSamples * numChannels * bytesPerSample

            FileOutputStream(demoFile).use { fos ->
                // Write 44-byte RIFF/WAVE header
                writeWavHeader(fos, dataSize, SAMPLE_RATE, numChannels, 16)

                val buffer = ByteBuffer.allocate(4096).order(ByteOrder.LITTLE_ENDIAN)
                val twoPi = 2.0 * PI

                // Chord roots: A2 (110Hz), F2 (87.3Hz), C3 (130.8Hz), G2 (98Hz)
                val chordRoots = doubleArrayOf(110.0, 87.3, 130.8, 98.0)

                for (sampleIdx in 0 until totalSamples) {
                    val time = sampleIdx.toDouble() / SAMPLE_RATE
                    val beatTime = (time * 2.0) % 1.0 // 120 BPM = 2 beats per sec
                    val barIndex = ((time / 2.0).toInt()) % chordRoots.size
                    val baseFreq = chordRoots[barIndex]

                    // 1. Kick Drum (60Hz -> 45Hz exponential pitch drop with snappy decay)
                    val kickDecay = exp(-beatTime * 14.0)
                    val kickFreq = 45.0 + 90.0 * kickDecay
                    val kick = sin(twoPi * kickFreq * beatTime) * kickDecay * 0.75

                    // 2. 808 Sub-Bass Note (Fundamental at 55Hz - 65Hz)
                    val subBassFreq = baseFreq * 0.5 // Sub octave (~43-65 Hz)
                    val subBass = sin(twoPi * subBassFreq * time) * 0.45

                    // 3. Stereo Chord Synthesizer (Root + Fifth + Minor/Major Third)
                    val chordFifth = baseFreq * 1.5
                    val chordThird = baseFreq * 1.2
                    val chordSynth = (sin(twoPi * baseFreq * time) +
                            sin(twoPi * chordThird * time) * 0.8 +
                            sin(twoPi * chordFifth * time) * 0.6) * 0.22

                    // 4. Arpeggiated high lead note (Stereo sweeping)
                    val arpStep = ((time * 8.0).toInt()) % 4
                    val arpFreq = baseFreq * (2.0 + arpStep * 0.5)
                    val arp = sin(twoPi * arpFreq * time) * 0.25

                    // Stereo Panning
                    val panL = 0.5 + 0.4 * sin(twoPi * 0.5 * time)
                    val panR = 1.0 - panL

                    val leftSignal = (kick + subBass + chordSynth * 0.9 + arp * panL).coerceIn(-1.0, 1.0)
                    val rightSignal = (kick + subBass + chordSynth * 0.9 + arp * panR).coerceIn(-1.0, 1.0)

                    val leftShort = (leftSignal * 30000.0).toInt().toShort()
                    val rightShort = (rightSignal * 30000.0).toInt().toShort()

                    if (buffer.remaining() < 4) {
                        fos.write(buffer.array(), 0, buffer.position())
                        buffer.clear()
                    }

                    buffer.putShort(leftShort)
                    buffer.putShort(rightShort)
                }

                if (buffer.position() > 0) {
                    fos.write(buffer.array(), 0, buffer.position())
                }
            }
            Log.d(TAG, "Successfully generated demo master track: ${demoFile.absolutePath} (${demoFile.length()} bytes)")
        } catch (e: Exception) {
            Log.e(TAG, "Failed generating demo audio: ${e.message}", e)
        }

        Uri.fromFile(demoFile)
    }

    private fun writeWavHeader(
        out: FileOutputStream,
        dataSize: Int,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val totalSize = dataSize + 36
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = channels * (bitsPerSample / 8)

        val header = ByteArray(44)
        val buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

        buf.put("RIFF".toByteArray())
        buf.putInt(totalSize)
        buf.put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray())
        buf.putInt(16) // SubChunk1Size (16 for PCM)
        buf.putShort(1) // AudioFormat (1 for PCM)
        buf.putShort(channels.toShort())
        buf.putInt(sampleRate)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())
        buf.put("data".toByteArray())
        buf.putInt(dataSize)

        out.write(header)
    }
}
