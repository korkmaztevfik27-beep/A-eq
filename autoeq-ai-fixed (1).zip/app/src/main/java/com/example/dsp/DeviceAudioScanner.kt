package com.example.dsp

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class ScannedAudio(
    val uri: Uri,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val size: Long,
    val displayName: String,
    val filePath: String?
)

object DeviceAudioScanner {
    private const val TAG = "DeviceAudioScanner"

    private val SUPPORTED_EXTENSIONS = setOf("mp3", "wav", "m4a", "flac", "ogg", "aac")

    suspend fun scanDeviceAudio(context: Context): List<ScannedAudio> = withContext(Dispatchers.IO) {
        val audioList = mutableListOf<ScannedAudio>()
        val seenSignatures = mutableSetOf<String>()

        // 1. Scan via MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        try {
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATA
            )

            // Broad query without fragile SQL LIKE filters: filter flexibly in Kotlin
            val selection = "${MediaStore.Audio.Media.SIZE} > 2048"
            val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val title = if (titleCol != -1) cursor.getString(titleCol) ?: "" else ""
                    val artist = if (artistCol != -1) cursor.getString(artistCol) ?: "" else ""
                    val duration = if (durationCol != -1) cursor.getLong(durationCol) else 0L
                    val name = if (nameCol != -1) cursor.getString(nameCol) ?: "audio_${id}.mp3" else "audio_${id}.mp3"
                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    val filePath = if (dataCol != -1) cursor.getString(dataCol) else null

                    val ext = name.substringAfterLast(".", "").lowercase()
                    val isAudioExt = ext in SUPPORTED_EXTENSIONS || duration > 0

                    if (isAudioExt) {
                        val cleanTitle = if (title.isBlank() || title == "<unknown>") {
                            name.substringBeforeLast(".")
                        } else title

                        val cleanArtist = if (artist.isBlank() || artist == "<unknown>") {
                            "Local Audio"
                        } else artist

                        val signature = "${name.lowercase()}_$size"
                        if (seenSignatures.add(signature)) {
                            audioList.add(
                                ScannedAudio(
                                    uri = contentUri,
                                    title = cleanTitle,
                                    artist = cleanArtist,
                                    durationMs = duration,
                                    size = size,
                                    displayName = name,
                                    filePath = filePath
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "MediaStore external scan failed: ${e.message}")
        }

        // 2. Scan via MediaStore.Files for any audio files not registered in Audio table
        try {
            val fileProjection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATA
            )
            val filesUri = MediaStore.Files.getContentUri("external")
            val selection = "${MediaStore.Files.FileColumns.SIZE} > 2048"

            context.contentResolver.query(
                filesUri,
                fileProjection,
                selection,
                null,
                "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val dataCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = if (nameCol != -1) cursor.getString(nameCol) ?: "" else ""
                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    val filePath = if (dataCol != -1) cursor.getString(dataCol) else null

                    val ext = name.substringAfterLast(".", "").lowercase()
                    if (ext in SUPPORTED_EXTENSIONS) {
                        val signature = "${name.lowercase()}_$size"
                        if (seenSignatures.add(signature)) {
                            val contentUri = ContentUris.withAppendedId(filesUri, id)
                            audioList.add(
                                ScannedAudio(
                                    uri = contentUri,
                                    title = name.substringBeforeLast("."),
                                    artist = "Local Audio",
                                    durationMs = 0L,
                                    size = size,
                                    displayName = name,
                                    filePath = filePath
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "MediaStore.Files scan failed: ${e.message}")
        }

        // 3. Direct storage directories scan (Downloads, Music, Recordings, SDCard, etc.)
        // This is crucial for newly downloaded files or emulators where MediaStore indexer hasn't run yet
        val directoriesToScan = mutableListOf<File>()
        try {
            directoriesToScan.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC))
            directoriesToScan.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
            directoriesToScan.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                directoriesToScan.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RECORDINGS))
            }
            directoriesToScan.add(File("/sdcard/Music"))
            directoriesToScan.add(File("/sdcard/Download"))
            directoriesToScan.add(File("/sdcard/Downloads"))
            directoriesToScan.add(File("/storage/emulated/0/Music"))
            directoriesToScan.add(File("/storage/emulated/0/Download"))
            directoriesToScan.add(File("/storage/emulated/0/Downloads"))

            // Base root storage
            directoriesToScan.add(Environment.getExternalStorageDirectory())

            context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.let { directoriesToScan.add(it) }
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let { directoriesToScan.add(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Directory list collection warning: ${e.message}")
        }

        for (dir in directoriesToScan) {
            if (dir.exists() && dir.canRead()) {
                scanDirectoryRecursively(dir, audioList, seenSignatures, maxDepth = 4)
            }
        }

        Log.d(TAG, "Scanned total ${audioList.size} audio files on device")
        audioList
    }

    private fun scanDirectoryRecursively(
        dir: File,
        results: MutableList<ScannedAudio>,
        seenSignatures: MutableSet<String>,
        maxDepth: Int
    ) {
        if (maxDepth < 0 || !dir.exists() || !dir.canRead()) return
        // Skip Android/data and Android/obb which are restricted by Scoped Storage
        val dirPath = dir.absolutePath
        if (dirPath.contains("/Android/data") || dirPath.contains("/Android/obb")) return

        val files = try {
            dir.listFiles()
        } catch (e: Exception) {
            null
        } ?: return

        for (file in files) {
            if (file.isDirectory && !file.name.startsWith(".")) {
                scanDirectoryRecursively(file, results, seenSignatures, maxDepth - 1)
            } else if (file.isFile && file.length() > 2048) {
                val ext = file.extension.lowercase()
                if (ext in SUPPORTED_EXTENSIONS) {
                    val signature = "${file.name.lowercase()}_${file.length()}"
                    if (seenSignatures.add(signature)) {
                        results.add(
                            ScannedAudio(
                                uri = Uri.fromFile(file),
                                title = file.nameWithoutExtension,
                                artist = "Device Audio",
                                durationMs = 0L,
                                size = file.length(),
                                displayName = file.name,
                                filePath = file.absolutePath
                            )
                        )
                    }
                }
            }
        }
    }
}
