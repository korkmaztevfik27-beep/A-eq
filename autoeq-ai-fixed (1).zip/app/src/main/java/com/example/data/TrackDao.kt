package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    @Query("SELECT * FROM analyzed_tracks ORDER BY timestamp DESC")
    fun getAllTracks(): Flow<List<AnalyzedTrack>>

    @Query("SELECT * FROM analyzed_tracks WHERE uriString = :uriString LIMIT 1")
    suspend fun getTrackByUri(uriString: String): AnalyzedTrack?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: AnalyzedTrack)

    @Delete
    suspend fun deleteTrack(track: AnalyzedTrack)

    @Query("DELETE FROM analyzed_tracks WHERE id = :id")
    suspend fun deleteTrackById(id: Int)

    @Query("DELETE FROM analyzed_tracks")
    suspend fun clearAll()
}
