package com.example.data

import kotlinx.coroutines.flow.Flow

class TrackRepository(private val trackDao: TrackDao) {
    val allTracks: Flow<List<AnalyzedTrack>> = trackDao.getAllTracks()

    suspend fun getTrackByUri(uriString: String): AnalyzedTrack? {
        return trackDao.getTrackByUri(uriString)
    }

    suspend fun insertTrack(track: AnalyzedTrack) {
        trackDao.insertTrack(track)
    }

    suspend fun deleteTrackById(id: Int) {
        trackDao.deleteTrackById(id)
    }

    suspend fun clearAll() {
        trackDao.clearAll()
    }
}
