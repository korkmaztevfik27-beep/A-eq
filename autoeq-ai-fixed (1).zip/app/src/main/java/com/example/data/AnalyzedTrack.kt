package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "analyzed_tracks")
data class AnalyzedTrack(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val uriString: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val detectedGenre: String,
    val sampleRate: Int,
    val bitDepth: Int,
    val rms: Double,
    val peak: Double,
    val truePeak: Double,
    val lufsIntegrated: Double,
    val lufsShortTerm: Double,
    val dynamicRange: Double,
    val crestFactor: Double,
    val spectralCentroid: Double,
    val spectralBandwidth: Double,
    val spectralRolloff: Double,
    val spectralFlatness: Double,
    val zeroCrossingRate: Double,
    val bassDensity: Double,
    val vocalPresence: Double,
    val sibilance: Double,
    val harshness: Double,
    val muddy: Double,
    val stereoWidth: Double,
    val stereoBalance: Double,
    val eqScore: Int,
    val eqBandsGainsCsv: String, // Comma-separated list of gains for 29 bands
    val melSpectrogramCsv: String, // Comma-separated list of float heights for 128 elements
    val timestamp: Long = System.currentTimeMillis()
)
