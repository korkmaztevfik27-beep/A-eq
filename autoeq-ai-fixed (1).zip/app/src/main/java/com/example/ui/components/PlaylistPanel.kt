package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AnalyzedTrack
import java.util.Locale
import kotlin.random.Random

@Composable
fun PlaylistPanel(
    tracks: List<AnalyzedTrack>,
    currentTrack: AnalyzedTrack?,
    onTrackSelected: (AnalyzedTrack) -> Unit,
    onTrackDeleted: (AnalyzedTrack) -> Unit,
    onScanRequested: () -> Unit,
    onPickFileRequested: () -> Unit,
    onLoadDemoRequested: () -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF14171E))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("playlist_panel_container")
    ) {
        // Panel Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.LibraryMusic,
                contentDescription = "Playlist Panel",
                tint = Color(0xFF00F5D4),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DSP MASTER PLAYLIST (${tracks.size})",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.weight(1f)
            )

            if (tracks.isNotEmpty()) {
                IconButton(
                    onClick = onScanRequested,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Cihazı Tara",
                        tint = Color(0xFF00F5D4),
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onPickFileRequested,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = "Dosya Seç",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onClearAll,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Listeyi Temizle",
                        tint = Color(0xFFFF5252).copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (tracks.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1117))
                    .border(1.dp, Color(0xFF1F2430), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color(0xFF00F5D4).copy(alpha = 0.8f),
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Cihazınızdaki Ses Dosyalarını Bulun",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Cihaz hafızasındaki ve İndirilenler klasöründeki MP3, M4A, WAV ve FLAC parçalarını otomatik tarayabilir veya dosya seçiciyle ekleyebilirsiniz.",
                    color = Color(0xFF8E95A5),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Primary Scan Device Button
                Button(
                    onClick = onScanRequested,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00F5D4),
                        contentColor = Color(0xFF0C0E12)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("scan_device_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CİHAZDAKİ MP3'LERİ TARA",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Pick File button
                    OutlinedButton(
                        onClick = onPickFileRequested,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF00E5FF)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("pick_file_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Dosya Seç",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Instant Demo track button
                    OutlinedButton(
                        onClick = onLoadDemoRequested,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF9D4EDD)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF9D4EDD).copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("load_demo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Örnek Demo",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "*Emülatörde henüz MP3 yoksa 'Örnek Demo' ile ses, bas ve ekolayzırı anında test edebilirsiniz.",
                    color = Color(0xFF6B7280),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center
                )
            }
            return@Column
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 240.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tracks, key = { it.id }) { track ->
                val isSelected = track.uriString == currentTrack?.uriString

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF1C202B) else Color.Transparent)
                        .clickable { onTrackSelected(track) }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Custom Generative Artwork
                    GenerativeAlbumArt(
                        seedName = track.title + track.artist,
                        modifier = Modifier.size(40.dp)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    // Track details info
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            color = if (isSelected) Color(0xFF00F5D4) else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = track.artist,
                                color = Color(0xFF8E95A5),
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFF222633),
                                shape = RoundedCornerShape(3.dp)
                            ) {
                                Text(
                                    text = track.detectedGenre,
                                    color = Color(0xFF00E5FF),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }

                    // Playing indicator or duration
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Currently Playing",
                            tint = Color(0xFF39FF14),
                            modifier = Modifier
                                .size(16.dp)
                                .padding(end = 4.dp)
                        )
                    } else {
                        val minutes = (track.durationMs / 1000) / 60
                        val seconds = (track.durationMs / 1000) % 60
                        Text(
                            text = String.format(Locale.US, "%02d:%02d", minutes, seconds),
                            color = Color(0xFF515970),
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Delete history item button
                    IconButton(
                        onClick = { onTrackDeleted(track) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete track from history",
                            tint = Color(0xFFFF5400).copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GenerativeAlbumArt(
    seedName: String,
    modifier: Modifier = Modifier
) {
    val seed = seedName.hashCode().toLong()
    val rand = Random(seed)

    // Generate colors for unique gradients
    val hue1 = rand.nextFloat() * 360f
    val hue2 = (hue1 + 120f) % 360f

    val color1 = Color.hsv(hue1, 0.8f, 0.8f)
    val color2 = Color.hsv(hue2, 0.9f, 0.9f)
    val shapeType = rand.nextInt(3)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0C0E12))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(6.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Base gradient
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(color1.copy(alpha = 0.2f), color2.copy(alpha = 0.4f)),
                    start = androidx.compose.ui.geometry.Offset(0f, 0f),
                    end = androidx.compose.ui.geometry.Offset(width, height)
                )
            )

            // 2. Geometric abstract shape
            when (shapeType) {
                0 -> {
                    // Glowing overlapping circles
                    drawCircle(
                        color = color1.copy(alpha = 0.5f),
                        radius = width * 0.35f,
                        center = androidx.compose.ui.geometry.Offset(width * 0.4f, height * 0.4f)
                    )
                    drawCircle(
                        color = color2.copy(alpha = 0.6f),
                        radius = width * 0.25f,
                        center = androidx.compose.ui.geometry.Offset(width * 0.6f, height * 0.6f)
                    )
                }
                1 -> {
                    // Asymmetric diagonal stripes
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(0f, height * 0.2f)
                        lineTo(width, height * 0.8f)
                        lineTo(width, height)
                        lineTo(0f, height * 0.4f)
                        close()
                    }
                    drawPath(
                        path = path,
                        color = color2.copy(alpha = 0.6f)
                    )
                }
                else -> {
                    // Stacked rounded panels
                    drawRoundRect(
                        color = color1.copy(alpha = 0.5f),
                        topLeft = androidx.compose.ui.geometry.Offset(width * 0.15f, height * 0.15f),
                        size = androidx.compose.ui.geometry.Size(width * 0.7f, height * 0.7f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                    )
                }
            }

            // Draw clean subtle border
            drawRect(
                color = color1.copy(alpha = 0.5f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
            )
        }
    }
}
