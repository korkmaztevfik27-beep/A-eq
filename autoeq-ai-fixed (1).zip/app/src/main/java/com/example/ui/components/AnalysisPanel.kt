package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AnalyzedTrack
import java.util.Locale

@Composable
fun AnalysisPanel(
    track: AnalyzedTrack?,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(0) } // 0 = Technical Metrics, 1 = Spectral Balances & AI

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF14171E))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("analysis_panel_container")
    ) {
        // Panel Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Analytics,
                contentDescription = "AI Audio Analysis",
                tint = Color(0xFF00F5D4),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "AI AUDIO INTELLIGENCE & DSP",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (track == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF515970),
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Upload an audio track to perform AI Analysis",
                        color = Color(0xFF8E95A5),
                        fontSize = 12.sp
                    )
                }
            }
            return@Column
        }

        // Custom Tab Selectors
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = Color.Transparent,
            contentColor = Color(0xFF00F5D4),
            indicator = { tabPositions ->
                if (activeTab in tabPositions.indices) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                        color = Color(0xFF00F5D4),
                        height = 2.dp
                    )
                }
            },
            divider = { HorizontalDivider(color = Color(0xFF222633)) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Physical Metrics", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Spectral Densities", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == 0) {
            // Tab 0: Physical & Technical Metrics
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCard(title = "Sample Rate", value = "${track.sampleRate} Hz", modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricCard(title = "Bit Depth", value = "${track.bitDepth} bit", modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCard(title = "RMS Level", value = String.format(Locale.US, "%.1f dBFS", track.rms), modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricCard(title = "Peak / True Peak", value = String.format(Locale.US, "%.1f / %.1f dB", track.peak, track.truePeak), modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCard(title = "LUFS Integrated", value = String.format(Locale.US, "%.1f LUFS", track.lufsIntegrated), modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricCard(title = "LUFS Short-Term", value = String.format(Locale.US, "%.1f LUFS", track.lufsShortTerm), modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCard(title = "Dynamic Range", value = String.format(Locale.US, "%.1f dB", track.dynamicRange), modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricCard(title = "Crest Factor", value = String.format(Locale.US, "%.2f", track.crestFactor), modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCard(title = "Spectral Centroid", value = String.format(Locale.US, "%.0f Hz", track.spectralCentroid), modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricCard(title = "Zero Crossing Rate", value = String.format(Locale.US, "%.4f", track.zeroCrossingRate), modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCard(title = "Spectral Flatness", value = String.format(Locale.US, "%.3f", track.spectralFlatness), modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricCard(title = "Spectral Rolloff", value = String.format(Locale.US, "%.0f Hz", track.spectralRolloff), modifier = Modifier.weight(1f))
                }
            }
        } else {
            // Tab 1: Spectral Densities, Micro-problem alerts & AI recommendations
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Spectral Density Sliders (Read-only elegant visual indicators)
                DensityBar(label = "Bass Density", value = track.bassDensity.toFloat(), color = Color(0xFF00E5FF))
                DensityBar(label = "Vocal Presence", value = track.vocalPresence.toFloat(), color = Color(0xFF00F5D4))
                DensityBar(label = "Sibilance Region", value = track.sibilance.toFloat(), color = Color(0xFF7B2CBF))
                DensityBar(label = "Mid-Frequency Muddiness", value = track.muddy.toFloat(), color = Color(0xFFFF9F1C))
                DensityBar(label = "Treble Harshness", value = track.harshness.toFloat(), color = Color(0xFFFF5400))
                DensityBar(label = "Stereo Width", value = track.stereoWidth.toFloat(), color = Color(0xFF39FF14))

                Spacer(modifier = Modifier.height(4.dp))

                // AI Expert Recommendations Highlight Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1C202B))
                        .border(1.dp, Color(0xFF2A2F3E), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFF39FF14),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AI RECOMMENDATIONS",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }

                        // EQ Score tag
                        Surface(
                            color = Color(0xFF00F5D4).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Score: ${track.eqScore}/100",
                                color = Color(0xFF00F5D4),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val aiGains = try {
                        track.eqBandsGainsCsv.split(",").map { it.toFloat() }
                    } catch (e: Exception) {
                        emptyList()
                    }

                    if (aiGains.size >= 29) {
                        // Extract sample representation values for recommendation matching Turkish user prompt
                        val bassRec = aiGains[3] // 60Hz
                        val lowMidRec = aiGains[9] // 250Hz
                        val presenceRec = aiGains[21] // 4kHz
                        val highShelfRec = aiGains[26] // 12kHz

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            RecommendationRow(band = "Bass (Sub)", value = bassRec)
                            RecommendationRow(band = "Low Mid (Muddiness)", value = lowMidRec)
                            RecommendationRow(band = "Presence (Clarity)", value = presenceRec)
                            RecommendationRow(band = "High Shelf (Air)", value = highShelfRec)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1C202B))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(text = title.uppercase(Locale.US), color = Color(0xFF8E95A5), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun DensityBar(
    label: String,
    value: Float,
    color: Color
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, color = Color(0xFF8E95A5), fontSize = 11.sp)
            Text(text = "${(value * 100).toInt()}%", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { value.coerceIn(0f, 1f) },
            color = color,
            trackColor = Color(0xFF1C202B),
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
        )
    }
}

@Composable
fun RecommendationRow(
    band: String,
    value: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = band, color = Color(0xFF8E95A5), fontSize = 11.sp)
        val formattedValue = String.format(Locale.US, "%+.1f dB", value)
        val color = if (value > 0f) Color(0xFF39FF14) else if (value < 0f) Color(0xFFFF5400) else Color.White
        Text(
            text = formattedValue,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
