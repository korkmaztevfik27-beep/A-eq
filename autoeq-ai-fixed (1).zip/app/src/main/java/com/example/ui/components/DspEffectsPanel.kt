package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material.icons.filled.SurroundSound
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DspEffectsPanel(
    bassStrength: Int,
    virtualizerStrength: Int,
    reverbPresetIdx: Int,
    onBassChanged: (Int) -> Unit,
    onVirtualizerChanged: (Int) -> Unit,
    onReverbChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val reverbPresets = listOf(
        "Bypass", "Small Room", "Medium Room", "Large Room", 
        "Medium Hall", "Large Hall", "Plate Reverb"
    )

    var showReverbMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF14171E))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("dsp_effects_panel")
    ) {
        // Section Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Hearing,
                contentDescription = "DSP Extra Effects",
                tint = Color(0xFF00F5D4),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "AMBIENCE & SPATIAL PROCESSORS",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bass Boost Slider
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SettingsVoice,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Sub-Bass Subharmonic Exciter",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "${bassStrength / 10}%",
                    color = Color(0xFF00E5FF),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Slider(
                value = bassStrength.toFloat() / 1000f,
                onValueChange = { onBassChanged((it * 1000).toInt()) },
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF00E5FF),
                    activeTrackColor = Color(0xFF00E5FF),
                    inactiveTrackColor = Color(0xFF222633)
                ),
                modifier = Modifier.fillMaxWidth().testTag("bass_boost_slider")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Virtualizer 3D Surround Slider
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SurroundSound,
                        contentDescription = null,
                        tint = Color(0xFF7B2CBF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "3D Acoustic Spatializer",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "${virtualizerStrength / 10}%",
                    color = Color(0xFF7B2CBF),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Slider(
                value = virtualizerStrength.toFloat() / 1000f,
                onValueChange = { onVirtualizerChanged((it * 1000).toInt()) },
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF7B2CBF),
                    activeTrackColor = Color(0xFF7B2CBF),
                    inactiveTrackColor = Color(0xFF222633)
                ),
                modifier = Modifier.fillMaxWidth().testTag("virtualizer_slider")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Reverb Environment Selector
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Environmental Acoustic Reverb Model",
                color = Color(0xFF8E95A5),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1C202B))
                    .border(1.dp, Color(0xFF2E3444), RoundedCornerShape(8.dp))
                    .clickable { showReverbMenu = true }
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .testTag("reverb_dropdown_trigger")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = reverbPresets.getOrElse(reverbPresetIdx) { "Bypass" },
                        color = if (reverbPresetIdx > 0) Color(0xFF00F5D4) else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "▼",
                        color = Color(0xFF515970),
                        fontSize = 10.sp
                    )
                }

                DropdownMenu(
                    expanded = showReverbMenu,
                    onDismissRequest = { showReverbMenu = false },
                    modifier = Modifier
                        .background(Color(0xFF1C202B))
                        .border(1.dp, Color(0xFF2E3444))
                ) {
                    reverbPresets.forEachIndexed { idx, name ->
                        DropdownMenuItem(
                            text = { 
                                Text(
                                    text = name, 
                                    color = if (reverbPresetIdx == idx) Color(0xFF00F5D4) else Color.White,
                                    fontWeight = if (reverbPresetIdx == idx) FontWeight.Bold else FontWeight.Normal
                                ) 
                            },
                            onClick = {
                                onReverbChanged(idx)
                                showReverbMenu = false
                            }
                        )
                    }
                }
            }
        }
    }
}
