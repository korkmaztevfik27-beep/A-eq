package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.AudioAnalyzer
import kotlin.math.log10
import kotlin.math.pow

@Composable
fun EqGraph(
    aiGains: FloatArray,
    manualGains: FloatArray,
    isEqActive: Boolean,
    onManualGainChanged: (Int, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val densities = LocalDensity.current
    val frequencies = AudioAnalyzer.EQ_FREQUENCIES

    // Key interactive control frequencies in the 29-band list
    // Indices corresponding to: 60Hz (idx 3), 250Hz (idx 9), 1kHz (idx 15), 4kHz (idx 21), 12kHz (idx 26)
    val controlIndices = listOf(3, 9, 15, 21, 26)
    val controlLabels = listOf("Bass", "Low-Mid", "Mid", "Presence", "Treble")

    val minFreqLog = log10(20.0)
    val maxFreqLog = log10(20000.0)
    val freqSpanLog = maxFreqLog - minFreqLog

    var canvasWidth by remember { mutableStateOf(1f) }
    var canvasHeight by remember { mutableStateOf(1f) }

    // Helper to map frequency to X coordinate
    fun getX(freq: Float, width: Float): Float {
        val freqLog = log10(freq.toDouble().coerceIn(20.0, 20000.0))
        val fraction = (freqLog - minFreqLog) / freqSpanLog
        return (fraction * width).toFloat()
    }

    // Helper to map DB gain to Y coordinate
    fun getY(gain: Float, height: Float): Float {
        // Range: -12 dB to +12 dB
        val fraction = (gain + 12f) / 24f
        return (height - (fraction * height)).toFloat()
    }

    // Reverse mapping from coordinates to gain value
    fun getGainFromY(y: Float, height: Float): Float {
        val fraction = (height - y) / height
        return (fraction * 24f - 12f).coerceIn(-12f, 12f)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F1116))
            .testTag("eq_graph_container")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isEqActive) {
                    if (!isEqActive) return@pointerInput
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val touchX = change.position.x
                        val touchY = change.position.y

                        // Find closest control node to touch point
                        var closestIdx = -1
                        var minDistance = Double.MAX_VALUE
                        for (idx in controlIndices) {
                            val freq = frequencies[idx]
                            val nodeX = getX(freq, canvasWidth)
                            val combinedGain = aiGains[idx] + manualGains[idx]
                            val nodeY = getY(combinedGain, canvasHeight)

                            val dist = Math.hypot((touchX - nodeX).toDouble(), (touchY - nodeY).toDouble())
                            if (dist < minDistance) {
                                minDistance = dist
                                closestIdx = idx
                            }
                        }

                        // Drag active if touch is reasonably close to a control point
                        if (closestIdx != -1 && minDistance < 100 * densities.density) {
                            val newGain = getGainFromY(touchY, canvasHeight)
                            // Offset is the difference between total desired gain and the AI baseline gain
                            val offsetGain = newGain - aiGains[closestIdx]
                            onManualGainChanged(closestIdx, offsetGain)
                        }
                    }
                }
        ) {
            canvasWidth = size.width
            canvasHeight = size.height

            // 1. Draw horizontal grid lines (dB levels)
            val dbGridLevels = listOf(-12, -6, 0, 6, 12)
            dbGridLevels.forEach { db ->
                val y = getY(db.toFloat(), canvasHeight)
                drawLine(
                    color = if (db == 0) Color(0xFF333A4D) else Color(0xFF1E222E),
                    start = Offset(0f, y),
                    end = Offset(canvasWidth, y),
                    strokeWidth = if (db == 0) 1.5f else 1f,
                    pathEffect = if (db != 0) PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f) else null
                )
            }

            // 2. Draw vertical grid lines (Logarithmic frequencies)
            val freqGridLines = listOf(20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000)
            freqGridLines.forEach { freq ->
                val x = getX(freq.toFloat(), canvasWidth)
                drawLine(
                    color = Color(0xFF1E222E),
                    start = Offset(x, 0f),
                    end = Offset(x, canvasHeight),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
                )
            }

            // 3. Draw AI baseline EQ curve (Dashed or dim if bypassed, solid cyan if active)
            val aiPath = Path()
            for (i in frequencies.indices) {
                val x = getX(frequencies[i], canvasWidth)
                val y = getY(aiGains[i], canvasHeight)
                if (i == 0) {
                    aiPath.moveTo(x, y)
                } else {
                    aiPath.lineTo(x, y)
                }
            }

            drawPath(
                path = aiPath,
                color = if (isEqActive) Color(0xFF00E5FF).copy(alpha = 0.35f) else Color(0xFF3A4254).copy(alpha = 0.4f),
                style = Stroke(
                    width = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                )
            )

            // 4. Draw Combined active EQ curve (Solid glowing curve)
            val activePath = Path()
            val fillPath = Path()
            fillPath.moveTo(0f, getY(0f, canvasHeight))

            for (i in frequencies.indices) {
                val x = getX(frequencies[i], canvasWidth)
                val currentGain = if (isEqActive) (aiGains[i] + manualGains[i]).coerceIn(-12f, 12f) else 0f
                val y = getY(currentGain, canvasHeight)

                if (i == 0) {
                    activePath.moveTo(x, y)
                    fillPath.lineTo(x, y)
                } else {
                    activePath.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
            }
            fillPath.lineTo(canvasWidth, getY(0f, canvasHeight))
            fillPath.close()

            // Draw area gradient fill
            if (isEqActive) {
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF00F5D4).copy(alpha = 0.15f), Color.Transparent),
                        startY = 0f,
                        endY = canvasHeight
                    )
                )
            }

            drawPath(
                path = activePath,
                color = if (isEqActive) Color(0xFF00F5D4) else Color(0xFF8E95A5),
                style = Stroke(width = if (isEqActive) 4f else 2f)
            )

            // 5. Draw manual control node handles
            if (isEqActive) {
                controlIndices.forEach { idx ->
                    val freq = frequencies[idx]
                    val x = getX(freq, canvasWidth)
                    val combinedGain = (aiGains[idx] + manualGains[idx]).coerceIn(-12f, 12f)
                    val y = getY(combinedGain, canvasHeight)

                    // Draw outer glow
                    drawCircle(
                        color = Color(0xFF00F5D4).copy(alpha = 0.3f),
                        radius = 22f,
                        center = Offset(x, y)
                    )

                    // Draw center dot
                    drawCircle(
                        color = Color(0xFF0C0E12),
                        radius = 12f,
                        center = Offset(x, y)
                    )

                    drawCircle(
                        color = Color(0xFF00F5D4),
                        radius = 8f,
                        center = Offset(x, y)
                    )
                }
            }
        }

        // Overlay text grids on borders
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column {
                Text("+12 dB", color = Color(0xFF515970), fontSize = 10.sp)
                Spacer(modifier = Modifier.weight(1f))
                Text("0 dB", color = Color(0xFF8E95A5), fontSize = 10.sp)
                Spacer(modifier = Modifier.weight(1f))
                Text("-12 dB", color = Color(0xFF515970), fontSize = 10.sp)
            }
        }

        // Overlay labels for control nodes
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 6.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            controlLabels.forEach { label ->
                Text(
                    text = label,
                    color = if (isEqActive) Color(0xFF8E95A5) else Color(0xFF515970),
                    fontSize = 10.sp
                )
            }
        }
    }
}
