package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = StudioDarkBg,
    primaryContainer = StudioCardLightBg,
    onPrimaryContainer = TextPrimary,
    secondary = CyberTeal,
    onSecondary = StudioDarkBg,
    tertiary = NeonGreen,
    background = StudioDarkBg,
    surface = StudioCardBg,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = StudioCardLightBg,
    onSurfaceVariant = TextSecondary,
    outline = DividerColor
)

private val LightColorScheme = DarkColorScheme // Forced Dark theme for a professional studio aesthetic

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme by default
    dynamicColor: Boolean = false, // Disable dynamic colors to keep brand colors intact
    content: @Composable () -> Unit,
) {
    val colorScheme = DarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
