package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioDarkBg = Color(0xFF0C0E12)
val StudioCardBg = Color(0xFF14171E)
val StudioCardLightBg = Color(0xFF1C202B)

val CyberCyan = Color(0xFF00F5D4)
val CyberTeal = Color(0xFF00E5FF)
val ElectricViolet = Color(0xFF7B2CBF)
val NeonGreen = Color(0xFF39FF14)

val TextPrimary = Color(0xFFF5F6F9)
val TextSecondary = Color(0xFF8E95A5)
val DividerColor = Color(0xFF222633)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
