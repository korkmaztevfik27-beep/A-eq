package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AnalyzedTrack
import com.example.ui.components.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: PlayerViewModel,
    modifier: Modifier = Modifier
) {
    val tracks by viewModel.allTracks.collectAsStateWithLifecycle()
    val currentTrack by viewModel.currentTrack.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val currentPosition by viewModel.currentPosition.collectAsStateWithLifecycle()
    val duration by viewModel.duration.collectAsStateWithLifecycle()
    val volume by viewModel.volume.collectAsStateWithLifecycle()
    val isMuted by viewModel.isMuted.collectAsStateWithLifecycle()
    val isEqActive by viewModel.isEqActive.collectAsStateWithLifecycle()
    val manualGains by viewModel.manualGains.collectAsStateWithLifecycle()
    val isShuffle by viewModel.isShuffle.collectAsStateWithLifecycle()
    val isRepeat by viewModel.isRepeat.collectAsStateWithLifecycle()
    val analysisState by viewModel.analysisState.collectAsStateWithLifecycle()
    val scanState by viewModel.scanState.collectAsStateWithLifecycle()

    val bassStrength by viewModel.bassBoostStrength.collectAsStateWithLifecycle()
    val virtualizerStrength by viewModel.virtualizerStrength.collectAsStateWithLifecycle()
    val reverbPresetIdx by viewModel.reverbPresetIdx.collectAsStateWithLifecycle()
    val playbackSpeed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
    val preAmpGain by viewModel.preAmpGain.collectAsStateWithLifecycle()
    val sleepTimerSecondsLeft by viewModel.sleepTimerSecondsLeft.collectAsStateWithLifecycle()
    val activePreset by viewModel.activePreset.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Runtime permission for MediaStore / Audio Storage
    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.scanDeviceTracks()
        } else {
            Toast.makeText(
                context,
                "Cihazdaki MP3 dosyalarını bulabilmek için depolama/medya izni gereklidir",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val startScan = {
        val hasPerm = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (hasPerm) {
            viewModel.scanDeviceTracks()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    // Document Picker supporting multiple files & all audio MIME types
    val multiDocPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.analyzeAndPlayMultipleFiles(uris)
        }
    }

    val pickAudioFiles = {
        multiDocPickerLauncher.launch(
            arrayOf(
                "audio/*",
                "audio/mpeg",
                "audio/mp3",
                "audio/x-wav",
                "audio/ogg",
                "audio/flac",
                "audio/aac",
                "application/octet-stream",
                "*/*"
            )
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = Color(0xFF00F5D4),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "AI MASTER PLAYER",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    // Scan Device Button (Cihazı Tara)
                    OutlinedButton(
                        onClick = startScan,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF00F5D4)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F5D4).copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .testTag("top_scan_device_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "TARA",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Load / Pick Track Button
                    Button(
                        onClick = pickAudioFiles,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00F5D4),
                            contentColor = Color(0xFF0C0E12)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("load_track_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "SEÇ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0C0E12),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF0C0E12)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Real-time Scanning Progress & Device Status Banner
                AnimatedVisibility(
                    visible = scanState !is ScanState.Idle,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    when (val currentScan = scanState) {
                        is ScanState.Scanning -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF14171E))
                                    .border(1.dp, Color(0xFF00F5D4).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(14.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(
                                            color = Color(0xFF00F5D4),
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "Cihaz Taranıyor...",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (currentScan.total > 0) {
                                                    "${currentScan.current} / ${currentScan.total}: ${currentScan.currentName}"
                                                } else currentScan.currentName,
                                                color = Color(0xFF8E95A5),
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    LinearProgressIndicator(
                                        progress = {
                                            if (currentScan.total > 0) currentScan.current.toFloat() / currentScan.total.toFloat() else 0f
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp)),
                                        color = Color(0xFF00F5D4),
                                        trackColor = Color(0xFF222633)
                                    )
                                }
                            }
                        }
                        is ScanState.Completed -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF0F1B18))
                                    .border(1.dp, Color(0xFF00F5D4).copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "✅ Tarama Tamamlandı! ${currentScan.addedCount} yeni müzik parçası eklendi (${currentScan.totalFound} dosya bulundu).",
                                        color = Color(0xFF00F5D4),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { viewModel.dismissScanState() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Kapat",
                                            tint = Color(0xFF00F5D4),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                        is ScanState.NoFilesFound -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E1712))
                                    .border(1.dp, Color(0xFFFFB703).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(14.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "ℹ️ Cihaz hafızasında MP3/ses dosyası bulunamadı. Emülatörde test etmek için hazır örnek şarkıyı ekleyebilirsiniz.",
                                            color = Color(0xFFFFB703),
                                            fontSize = 12.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(
                                            onClick = { viewModel.dismissScanState() },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Kapat",
                                                tint = Color(0xFFFFB703),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.loadDemoTrack()
                                            viewModel.dismissScanState()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFFFB703),
                                            contentColor = Color(0xFF0C0E12)
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Örnek Demo Şarkı Ekle",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                        is ScanState.Error -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF241212))
                                    .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "❌ Tarama Hatası: ${currentScan.message}",
                                        color = Color(0xFFFF5252),
                                        fontSize = 12.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { viewModel.dismissScanState() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Kapat",
                                            tint = Color(0xFFFF5252),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                        ScanState.Idle -> {}
                    }
                }

                // Analysis Error Banner
                AnimatedVisibility(
                    visible = analysisState is AnalysisState.Error,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    val errorState = analysisState as? AnalysisState.Error
                    if (errorState != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF241212))
                                .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "⚠️ Ses Analizi Hatası: ${errorState.message}",
                                    color = Color(0xFFFF5252),
                                    fontSize = 12.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { viewModel.dismissAnalysisState() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Kapat",
                                        tint = Color(0xFFFF5252),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // 1. Interactive Analysis Loader Overlay
                AnimatedVisibility(
                    visible = analysisState is AnalysisState.Analyzing,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF14171E))
                            .border(1.dp, Color(0xFF00F5D4).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                color = Color(0xFF00F5D4),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "Analyzing spectral features...",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Running local 20-band FFT decoding and AI curve mapping",
                                    color = Color(0xFF8E95A5),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // 2. Main Music Hero Info & Abstract Generative Artwork
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF14171E))
                        .border(1.dp, Color(0xFF222633), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Generative Abstract Album Art
                    GenerativeAlbumArt(
                        seedName = currentTrack?.let { it.title + it.artist } ?: "Placeholder Seed",
                        modifier = Modifier
                            .size(160.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Title
                    Text(
                        text = currentTrack?.title ?: "No Track Loaded",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Artist
                    Text(
                        text = currentTrack?.artist ?: "Unknown Source",
                        color = Color(0xFF8E95A5),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Detected Genre Glowing Badge
                    currentTrack?.let { track ->
                        Surface(
                            color = Color(0xFF00F5D4).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F5D4).copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = Color(0xFF00F5D4),
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "GENRE: ${track.detectedGenre.uppercase(Locale.US)}",
                                    color = Color(0xFF00F5D4),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }

                // 3. Real-time Spektrum / Equalizer Visualizer
                SpectrogramVisualizer(
                    isPlaying = isPlaying,
                    currentTrack = currentTrack,
                    modifier = Modifier.fillMaxWidth()
                )

                // 4. Music Player Controls Panel
                ControlPanel(
                    isPlaying = isPlaying,
                    currentPositionMs = currentPosition,
                    durationMs = duration,
                    volume = volume,
                    isMuted = isMuted,
                    isEqActive = isEqActive,
                    isShuffle = isShuffle,
                    isRepeat = isRepeat,
                    playbackSpeed = playbackSpeed,
                    preAmpGain = preAmpGain,
                    sleepTimerSecondsLeft = sleepTimerSecondsLeft,
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onPlayPrevious = { viewModel.playPrevious() },
                    onPlayNext = { viewModel.playNext() },
                    onSeekTo = { viewModel.seekTo(it) },
                    onSeekBy = { viewModel.seekBy(it) },
                    onSetVolume = { viewModel.setVolume(it) },
                    onToggleMute = { viewModel.toggleMute() },
                    onToggleEq = { viewModel.toggleEq() },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onToggleRepeat = { viewModel.toggleRepeat() },
                    onSetPlaybackSpeed = { viewModel.setPlaybackSpeed(it) },
                    onSetPreAmpGain = { viewModel.setPreAmpGain(it) },
                    onSetSleepTimer = { viewModel.setSleepTimer(it) }
                )

                // 4b. Ambient Ambience & Spatial Processors
                if (currentTrack != null) {
                    DspEffectsPanel(
                        bassStrength = bassStrength,
                        virtualizerStrength = virtualizerStrength,
                        reverbPresetIdx = reverbPresetIdx,
                        onBassChanged = { viewModel.setBassBoostStrength(it) },
                        onVirtualizerChanged = { viewModel.setVirtualizerStrength(it) },
                        onReverbChanged = { viewModel.setReverbPreset(it) }
                    )
                }

                // 5. Interactive EQ Graph
                if (currentTrack != null) {
                    val aiGains = viewModel.playerManager.getAiGains(currentTrack!!)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF14171E))
                            .border(1.dp, Color(0xFF222633), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "AI PARAMETRIC EQ CURVE",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Surface(
                                color = if (isEqActive) Color(0xFF39FF14).copy(alpha = 0.15f) else Color(0xFFFF5400).copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (isEqActive) "AI EQ: ACTIVE" else "AI EQ: BYPASS",
                                    color = if (isEqActive) Color(0xFF39FF14) else Color(0xFFFF5400),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick EQ Presets Row
                        val eqPresets = listOf(
                            "AI Auto Master",
                            "Bass Boost",
                            "Vocal Clarity",
                            "Electronic / EDM",
                            "Rock & Metal",
                            "Acoustic / Warm",
                            "Podcast / Voice",
                            "Flat / Bypass"
                        )
                        androidx.compose.foundation.lazy.LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(eqPresets.size) { idx ->
                                val preset = eqPresets[idx]
                                val isSelected = activePreset == preset
                                Surface(
                                    onClick = { viewModel.applyEqPreset(preset) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) Color(0xFF00F5D4).copy(alpha = 0.18f) else Color(0xFF1C202B),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) Color(0xFF00F5D4) else Color(0xFF2E3444)
                                    ),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = preset,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) Color(0xFF00F5D4) else Color(0xFF8E95A5)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        EqGraph(
                            aiGains = aiGains,
                            manualGains = manualGains,
                            isEqActive = isEqActive,
                            onManualGainChanged = { idx, gain ->
                                viewModel.updateManualGain(idx, gain)
                            }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Drag control nodes directly to customize curve fine-tuning.",
                            color = Color(0xFF515970),
                            fontSize = 10.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // 6. Deep Audio Analysis Parameters & AI Suggestions Panel
                AnalysisPanel(track = currentTrack)

                // 7. Playlist History Manager Panel
                PlaylistPanel(
                    tracks = tracks,
                    currentTrack = currentTrack,
                    onTrackSelected = { viewModel.playTrack(it) },
                    onTrackDeleted = { viewModel.deleteTrack(it) },
                    onScanRequested = startScan,
                    onPickFileRequested = pickAudioFiles,
                    onLoadDemoRequested = { viewModel.loadDemoTrack() },
                    onClearAll = { viewModel.clearAll() }
                )
            }
        }
    }
}

