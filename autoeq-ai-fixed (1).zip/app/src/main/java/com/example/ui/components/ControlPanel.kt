package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun ControlPanel(
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    volume: Float,
    isMuted: Boolean,
    isEqActive: Boolean,
    isShuffle: Boolean,
    isRepeat: Boolean,
    playbackSpeed: Float = 1.0f,
    preAmpGain: Float = 0.0f,
    sleepTimerSecondsLeft: Long? = null,
    onTogglePlayPause: () -> Unit,
    onPlayPrevious: () -> Unit,
    onPlayNext: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekBy: (Long) -> Unit = {},
    onSetVolume: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleEq: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onSetPlaybackSpeed: (Float) -> Unit = {},
    onSetPreAmpGain: (Float) -> Unit = {},
    onSetSleepTimer: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    // Format duration helper (e.g. 00:42 / 03:58)
    fun formatTime(ms: Long): String {
        val totalSecs = ms / 1000
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    // Remaining time helper
    fun formatRemainingTime(current: Long, total: Long): String {
        val remaining = maxOf(0L, total - current)
        return "-" + formatTime(remaining)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF14171E))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("control_panel_container")
    ) {
        var isSeeking by remember { mutableStateOf(false) }
        var seekFraction by remember { mutableFloatStateOf(0f) }

        val currentProgress = if (isSeeking) {
            seekFraction
        } else {
            if (durationMs > 0) (currentPositionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
        }

        val displayCurrentMs = if (isSeeking) {
            (seekFraction * durationMs).toLong()
        } else {
            currentPositionMs
        }

        // 1. Time seek bar & Labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = formatTime(displayCurrentMs),
                color = Color(0xFF8E95A5),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = formatRemainingTime(displayCurrentMs, durationMs),
                color = Color(0xFF515970),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Slider(
            value = currentProgress,
            onValueChange = {
                isSeeking = true
                seekFraction = it
            },
            onValueChangeFinished = {
                isSeeking = false
                onSeekTo((seekFraction * durationMs).toLong())
            },
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00F5D4),
                activeTrackColor = Color(0xFF00F5D4),
                inactiveTrackColor = Color(0xFF222633)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("playback_seekbar")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Playback Button Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Shuffle
            IconButton(
                onClick = onToggleShuffle,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("shuffle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (isShuffle) Color(0xFF00F5D4) else Color(0xFF515970),
                    modifier = Modifier.size(20.dp)
                )
            }

            // Rewind 10s
            IconButton(
                onClick = { onSeekBy(-10000L) },
                modifier = Modifier
                    .size(40.dp)
                    .testTag("rewind_10s_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FastRewind,
                    contentDescription = "10s Geri",
                    tint = Color(0xFF8E95A5),
                    modifier = Modifier.size(22.dp)
                )
            }

            // Previous
            IconButton(
                onClick = onPlayPrevious,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("previous_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipPrevious,
                    contentDescription = "Previous Track",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Central Play/Pause Circular Action button
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00F5D4))
                    .clickable { onTogglePlayPause() }
                    .testTag("play_pause_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color(0xFF0C0E12),
                    modifier = Modifier.size(28.dp)
                )
            }

            // Next
            IconButton(
                onClick = onPlayNext,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("next_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Next Track",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Forward 10s
            IconButton(
                onClick = { onSeekBy(10000L) },
                modifier = Modifier
                    .size(40.dp)
                    .testTag("forward_10s_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FastForward,
                    contentDescription = "10s İleri",
                    tint = Color(0xFF8E95A5),
                    modifier = Modifier.size(22.dp)
                )
            }

            // Repeat
            IconButton(
                onClick = onToggleRepeat,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("repeat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Repeat,
                    contentDescription = "Repeat",
                    tint = if (isRepeat) Color(0xFF00F5D4) else Color(0xFF515970),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3. Audio Volume Control Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleMute,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("mute_button")
            ) {
                Icon(
                    imageVector = if (isMuted || volume == 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                    contentDescription = "Mute",
                    tint = Color(0xFF8E95A5)
                )
            }

            Slider(
                value = if (isMuted) 0f else volume,
                onValueChange = onSetVolume,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF8E95A5),
                    activeTrackColor = Color(0xFF8E95A5),
                    inactiveTrackColor = Color(0xFF222633)
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("volume_slider")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3b. DSP Master Tools Bar: Speed, Sleep Timer & Pre-Amp Gain
        var showSpeedMenu by remember { mutableStateOf(false) }
        var showTimerMenu by remember { mutableStateOf(false) }
        var showPreAmpMenu by remember { mutableStateOf(false) }

        val speedOptions = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val timerOptions = listOf(0 to "Kapalı", 15 to "15 dk", 30 to "30 dk", 45 to "45 dk", 60 to "60 dk")
        val preAmpOptions = listOf(0f to "0 dB (Normal)", 3f to "+3 dB (Hafif)", 6f to "+6 dB (Güçlü)", 9f to "+9 dB (Yüksek)", 12f to "+12 dB (Maks)")

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Speed Chip
            Box(modifier = Modifier.weight(1f)) {
                Surface(
                    onClick = { showSpeedMenu = true },
                    shape = RoundedCornerShape(8.dp),
                    color = if (playbackSpeed != 1.0f) Color(0xFF00F5D4).copy(alpha = 0.15f) else Color(0xFF1C202B),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (playbackSpeed != 1.0f) Color(0xFF00F5D4) else Color(0xFF2E3444)
                    ),
                    modifier = Modifier.fillMaxWidth().height(34.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "⚡ ${playbackSpeed}x",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (playbackSpeed != 1.0f) Color(0xFF00F5D4) else Color(0xFF8E95A5)
                        )
                    }
                }
                DropdownMenu(
                    expanded = showSpeedMenu,
                    onDismissRequest = { showSpeedMenu = false },
                    modifier = Modifier.background(Color(0xFF1C202B)).border(1.dp, Color(0xFF2E3444))
                ) {
                    speedOptions.forEach { spd ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "${spd}x Hız",
                                    color = if (playbackSpeed == spd) Color(0xFF00F5D4) else Color.White,
                                    fontWeight = if (playbackSpeed == spd) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                onSetPlaybackSpeed(spd)
                                showSpeedMenu = false
                            }
                        )
                    }
                }
            }

            // Sleep Timer Chip
            Box(modifier = Modifier.weight(1.3f)) {
                val timerText = if (sleepTimerSecondsLeft != null) {
                    val m = sleepTimerSecondsLeft / 60
                    val s = sleepTimerSecondsLeft % 60
                    String.format(Locale.US, "⏱️ %02d:%02d", m, s)
                } else {
                    "⏱️ Uyku"
                }

                Surface(
                    onClick = { showTimerMenu = true },
                    shape = RoundedCornerShape(8.dp),
                    color = if (sleepTimerSecondsLeft != null) Color(0xFFFFB703).copy(alpha = 0.15f) else Color(0xFF1C202B),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (sleepTimerSecondsLeft != null) Color(0xFFFFB703) else Color(0xFF2E3444)
                    ),
                    modifier = Modifier.fillMaxWidth().height(34.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = timerText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (sleepTimerSecondsLeft != null) Color(0xFFFFB703) else Color(0xFF8E95A5)
                        )
                    }
                }
                DropdownMenu(
                    expanded = showTimerMenu,
                    onDismissRequest = { showTimerMenu = false },
                    modifier = Modifier.background(Color(0xFF1C202B)).border(1.dp, Color(0xFF2E3444))
                ) {
                    timerOptions.forEach { (mins, label) ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = label,
                                    color = Color.White
                                )
                            },
                            onClick = {
                                onSetSleepTimer(mins)
                                showTimerMenu = false
                            }
                        )
                    }
                }
            }

            // Pre-Amp Gain Chip
            Box(modifier = Modifier.weight(1.1f)) {
                Surface(
                    onClick = { showPreAmpMenu = true },
                    shape = RoundedCornerShape(8.dp),
                    color = if (preAmpGain > 0f) Color(0xFF39FF14).copy(alpha = 0.15f) else Color(0xFF1C202B),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (preAmpGain > 0f) Color(0xFF39FF14) else Color(0xFF2E3444)
                    ),
                    modifier = Modifier.fillMaxWidth().height(34.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (preAmpGain > 0f) "+${preAmpGain.toInt()}dB Pre" else "Pre-Amp",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (preAmpGain > 0f) Color(0xFF39FF14) else Color(0xFF8E95A5)
                        )
                    }
                }
                DropdownMenu(
                    expanded = showPreAmpMenu,
                    onDismissRequest = { showPreAmpMenu = false },
                    modifier = Modifier.background(Color(0xFF1C202B)).border(1.dp, Color(0xFF2E3444))
                ) {
                    preAmpOptions.forEach { (gain, label) ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = label,
                                    color = if (preAmpGain == gain) Color(0xFF39FF14) else Color.White,
                                    fontWeight = if (preAmpGain == gain) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                onSetPreAmpGain(gain)
                                showPreAmpMenu = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Comparison A/B Toggle Buttons matching the exact mockups
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ORIGINAL BUTTON
            Button(
                onClick = { if (isEqActive) onToggleEq() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!isEqActive) Color(0xFF222633) else Color(0xFF1C202B),
                    contentColor = if (!isEqActive) Color.White else Color(0xFF8E95A5)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .border(
                        1.dp,
                        if (!isEqActive) Color(0xFF00F5D4) else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    )
                    .testTag("ab_original_button")
            ) {
                Text(
                    text = "ORIGINAL",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            // AI EQ BUTTON
            Button(
                onClick = { if (!isEqActive) onToggleEq() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEqActive) Color(0xFF00F5D4) else Color(0xFF1C202B),
                    contentColor = if (isEqActive) Color(0xFF0C0E12) else Color(0xFF8E95A5)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .border(
                        1.dp,
                        if (isEqActive) Color(0xFF00F5D4) else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    )
                    .testTag("ab_aieq_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "AI EQ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}
