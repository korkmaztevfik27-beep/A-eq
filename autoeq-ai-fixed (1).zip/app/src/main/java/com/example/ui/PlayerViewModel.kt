package com.example.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AnalyzedTrack
import com.example.data.AppDatabase
import com.example.data.TrackRepository
import com.example.dsp.AudioAnalyzer
import com.example.dsp.AudioDemoGenerator
import com.example.dsp.AudioPlayerManager
import com.example.dsp.DeviceAudioScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

sealed interface AnalysisState {
    object Idle : AnalysisState
    object Analyzing : AnalysisState
    data class Success(val track: AnalyzedTrack) : AnalysisState
    data class Error(val message: String) : AnalysisState
}

sealed interface ScanState {
    object Idle : ScanState
    data class Scanning(val current: Int, val total: Int, val currentName: String) : ScanState
    data class Completed(val addedCount: Int, val totalFound: Int) : ScanState
    object NoFilesFound : ScanState
    data class Error(val message: String) : ScanState
}

class PlayerViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "PlayerViewModel"

    private val database = AppDatabase.getDatabase(application)
    private val repository = TrackRepository(database.trackDao())
    val playerManager = AudioPlayerManager(application)

    // UI state flows
    val allTracks: StateFlow<List<AnalyzedTrack>> = repository.allTracks
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _analysisState = MutableStateFlow<AnalysisState>(AnalysisState.Idle)
    val analysisState: StateFlow<AnalysisState> = _analysisState.asStateFlow()

    private val _scanState = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _scanState.asStateFlow()

    // Expose PlayerManager state flows directly
    val isPlaying = playerManager.isPlaying
    val currentPosition = playerManager.currentPosition
    val duration = playerManager.duration
    val volume = playerManager.volume
    val isMuted = playerManager.isMuted
    val isEqActive = playerManager.isEqActive
    val currentTrack = playerManager.currentTrack
    val manualGains = playerManager.manualGains
    val bassBoostStrength = playerManager.bassBoostStrength
    val virtualizerStrength = playerManager.virtualizerStrength
    val reverbPresetIdx = playerManager.reverbPresetIdx
    val playbackSpeed = playerManager.playbackSpeed
    val preAmpGain = playerManager.preAmpGain
    val sleepTimerSecondsLeft = playerManager.sleepTimerSecondsLeft
    val activePreset = playerManager.activePreset

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _isRepeat = MutableStateFlow(false)
    val isRepeat: StateFlow<Boolean> = _isRepeat.asStateFlow()

    init {
        viewModelScope.launch {
            // Check if database is empty on start; if so, preload demo track so the player is ready immediately!
            val initialTracks = repository.allTracks.first()
            if (initialTracks.isEmpty()) {
                loadDemoTrack(autoPlay = false)
            } else {
                playerManager.setPlaylist(initialTracks, 0, autoPlay = false)
            }

            allTracks.collect { tracks ->
                val current = currentTrack.value
                val index = tracks.indexOfFirst { it.uriString == current?.uriString }
                if (index != -1 && current != null) {
                    playerManager.updatePlaylistPreservingPlayback(tracks, index)
                } else if (current == null && tracks.isNotEmpty()) {
                    playerManager.setPlaylist(tracks, 0, autoPlay = false)
                } else {
                    playerManager.updatePlaylistPreservingPlayback(tracks, index)
                }
            }
        }
    }

    fun analyzeAndPlayFile(uri: Uri) {
        viewModelScope.launch {
            _analysisState.value = AnalysisState.Analyzing
            try {
                val originalName = getFileName(uri)
                val cachedFile = copyUriToCache(uri, originalName)
                val cachedUri = Uri.fromFile(cachedFile)

                // Check if already analyzed previously
                val existing = repository.getTrackByUri(cachedUri.toString())
                if (existing != null) {
                    _analysisState.value = AnalysisState.Success(existing)
                    playTrack(existing)
                    return@launch
                }

                // Analyze track in background coroutine dispatcher
                val result = AudioAnalyzer.analyzeAudio(getApplication(), cachedUri)
                repository.insertTrack(result)

                _analysisState.value = AnalysisState.Success(result)
                playTrack(result)
            } catch (e: Exception) {
                Log.e(TAG, "Analysis failed: ${e.message}", e)
                _analysisState.value = AnalysisState.Error(e.localizedMessage ?: "Spectral extraction failed")
            }
        }
    }

    fun analyzeAndPlayMultipleFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _analysisState.value = AnalysisState.Analyzing
            var firstTrack: AnalyzedTrack? = null
            var addedCount = 0

            for (uri in uris) {
                try {
                    val originalName = getFileName(uri)
                    val cachedFile = copyUriToCache(uri, originalName)
                    val cachedUri = Uri.fromFile(cachedFile)

                    val existing = repository.getTrackByUri(cachedUri.toString())
                    if (existing != null) {
                        if (firstTrack == null) firstTrack = existing
                        continue
                    }

                    val result = AudioAnalyzer.analyzeAudio(getApplication(), cachedUri)
                    repository.insertTrack(result)
                    addedCount++
                    if (firstTrack == null) firstTrack = result
                } catch (e: Exception) {
                    Log.e(TAG, "Batch analysis failed for $uri: ${e.message}")
                }
            }

            if (firstTrack != null) {
                _analysisState.value = AnalysisState.Success(firstTrack)
                playTrack(firstTrack)
            } else {
                _analysisState.value = AnalysisState.Error("Seçilen ses dosyaları okunamadı veya biçim desteklenmiyor.")
            }
        }
    }

    fun dismissScanState() {
        _scanState.value = ScanState.Idle
    }

    fun dismissAnalysisState() {
        _analysisState.value = AnalysisState.Idle
    }

    fun scanDeviceTracks() {
        viewModelScope.launch {
            _scanState.value = ScanState.Scanning(0, 0, "Cihaz taranıyor...")
            try {
                val scannedItems = DeviceAudioScanner.scanDeviceAudio(getApplication())
                if (scannedItems.isEmpty()) {
                    _scanState.value = ScanState.NoFilesFound
                    return@launch
                }

                val existingTracks = repository.allTracks.first()
                val existingTitles = existingTracks.map { it.title.lowercase().trim() }.toSet()
                val existingUris = existingTracks.map { it.uriString }.toSet()

                var addedCount = 0
                for ((index, item) in scannedItems.withIndex()) {
                    _scanState.value = ScanState.Scanning(index + 1, scannedItems.size, item.title)

                    if (existingTitles.contains(item.title.lowercase().trim()) || existingUris.contains(item.uri.toString())) {
                        continue
                    }

                    try {
                        val cachedFile = copyUriToCache(item.uri, item.displayName)
                        val cachedUri = Uri.fromFile(cachedFile)

                        val analyzed = AudioAnalyzer.analyzeAudio(getApplication(), cachedUri)
                        val finalTrack = if (analyzed.title == "Unknown Track" || analyzed.title == "Track Source") {
                            analyzed.copy(title = item.title, artist = item.artist)
                        } else analyzed

                        repository.insertTrack(finalTrack)
                        addedCount++

                        if (currentTrack.value == null && addedCount == 1) {
                            playTrack(finalTrack)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed caching scanned audio ${item.title}: ${e.message}")
                    }
                }

                _scanState.value = ScanState.Completed(addedCount, scannedItems.size)
            } catch (e: Exception) {
                Log.e(TAG, "Device scan failed: ${e.message}", e)
                _scanState.value = ScanState.Error(e.localizedMessage ?: "Cihaz taraması başarısız oldu")
            }
        }
    }

    fun loadDemoTrack(autoPlay: Boolean = true) {
        viewModelScope.launch {
            _analysisState.value = AnalysisState.Analyzing
            try {
                val demoUri = AudioDemoGenerator.generateDemoAudio(getApplication())
                val existing = repository.getTrackByUri(demoUri.toString())
                if (existing != null) {
                    _analysisState.value = AnalysisState.Success(existing)
                    if (autoPlay) {
                        playTrack(existing)
                    } else {
                        val tracks = repository.allTracks.first()
                        val idx = tracks.indexOfFirst { it.uriString == existing.uriString }
                        playerManager.setPlaylist(if (idx != -1) tracks else listOf(existing), if (idx != -1) idx else 0, autoPlay = false)
                    }
                    return@launch
                }

                val analyzed = AudioAnalyzer.analyzeAudio(getApplication(), demoUri)
                val demoTrack = analyzed.copy(
                    title = "Neon Synthwave (Master Demo)",
                    artist = "DSP Audio Lab",
                    detectedGenre = "Electronic / Synthwave"
                )
                repository.insertTrack(demoTrack)
                _analysisState.value = AnalysisState.Success(demoTrack)
                if (autoPlay) {
                    playTrack(demoTrack)
                } else {
                    playerManager.setPlaylist(listOf(demoTrack), 0, autoPlay = false)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed loading demo: ${e.message}", e)
                _analysisState.value = AnalysisState.Error(e.localizedMessage ?: "Demo yüklenemedi")
            }
        }
    }

    private suspend fun getFileName(uri: Uri): String = withContext(Dispatchers.IO) {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = getApplication<Application>().contentResolver.query(uri, null, null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index != -1) {
                        result = cursor.getString(index)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to resolve file name: ${e.message}")
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/') ?: -1
            if (cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        result ?: "track_${System.currentTimeMillis()}.mp3"
    }

    private suspend fun copyUriToCache(uri: Uri, fileName: String): File = withContext(Dispatchers.IO) {
        val cacheDir = File(getApplication<Application>().cacheDir, "dsp_tracks")
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }

        // If file already exists inside the cacheDir, return it directly
        if (uri.scheme == "file") {
            val srcFile = File(uri.path ?: "")
            if (srcFile.exists()) {
                if (srcFile.parentFile?.absolutePath == cacheDir.absolutePath) {
                    return@withContext srcFile
                }
                val safeName = "${System.currentTimeMillis()}_$fileName"
                val destFile = File(cacheDir, safeName)
                FileInputStream(srcFile).use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                return@withContext destFile
            }
        }

        // Otherwise copy from content resolver
        val safeName = "${System.currentTimeMillis()}_$fileName"
        val destFile = File(cacheDir, safeName)
        val inputStream = getApplication<Application>().contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Cannot open input stream for URI: $uri")

        inputStream.use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }

        if (destFile.length() == 0L) {
            destFile.delete()
            throw IllegalStateException("Copied file is 0 bytes")
        }

        destFile
    }

    fun playTrack(track: AnalyzedTrack) {
        val tracks = allTracks.value
        val index = tracks.indexOfFirst { it.uriString == track.uriString }
        if (index != -1) {
            playerManager.setPlaylist(tracks, index)
        } else {
            playerManager.playTrack(track)
        }
    }

    fun togglePlayPause() {
        if (currentTrack.value == null && allTracks.value.isEmpty()) {
            loadDemoTrack(autoPlay = true)
        } else {
            playerManager.togglePlayPause()
        }
    }

    fun playNext() {
        playerManager.playNext()
    }

    fun playPrevious() {
        playerManager.playPrevious()
    }

    fun seekTo(positionMs: Long) {
        playerManager.seekTo(positionMs)
    }

    fun setVolume(vol: Float) {
        playerManager.setVolume(vol)
    }

    fun toggleMute() {
        playerManager.toggleMute()
    }

    fun toggleEq() {
        playerManager.toggleEq()
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
        playerManager.toggleShuffle(_isShuffle.value)
    }

    fun toggleRepeat() {
        _isRepeat.value = !_isRepeat.value
        playerManager.toggleRepeat(_isRepeat.value)
    }

    fun updateManualGain(bandIndex: Int, newGain: Float) {
        playerManager.updateManualGain(bandIndex, newGain)
    }

    fun deleteTrack(track: AnalyzedTrack) {
        viewModelScope.launch {
            if (currentTrack.value?.uriString == track.uriString) {
                playerManager.stopPlayback()
            }
            // Delete associated file in the dsp_tracks local cache
            try {
                val uri = Uri.parse(track.uriString)
                if (uri.scheme == "file") {
                    val file = uri.path?.let { File(it) }
                    if (file != null && file.exists()) {
                        file.delete()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete cache file: ${e.message}")
            }
            repository.deleteTrackById(track.id)
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            playerManager.stopPlayback()
            // Recursively clear internal cache
            try {
                val cacheDir = File(getApplication<Application>().cacheDir, "dsp_tracks")
                if (cacheDir.exists()) {
                    cacheDir.deleteRecursively()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to clear cache: ${e.message}")
            }
            repository.clearAll()
        }
    }

    fun setBassBoostStrength(strength: Int) {
        playerManager.setBassBoostStrength(strength)
    }

    fun setVirtualizerStrength(strength: Int) {
        playerManager.setVirtualizerStrength(strength)
    }

    fun setReverbPreset(presetIdx: Int) {
        playerManager.setReverbPreset(presetIdx)
    }

    fun setPlaybackSpeed(speed: Float) {
        playerManager.setPlaybackSpeed(speed)
    }

    fun setPreAmpGain(gainDb: Float) {
        playerManager.setPreAmpGain(gainDb)
    }

    fun setSleepTimer(minutes: Int) {
        playerManager.setSleepTimer(minutes)
    }

    fun seekBy(deltaMs: Long) {
        playerManager.seekBy(deltaMs)
    }

    fun applyEqPreset(presetName: String) {
        playerManager.applyPreset(presetName)
    }

    fun resetManualGains() {
        playerManager.resetManualGains()
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
