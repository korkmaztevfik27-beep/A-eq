package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AnalyzedTrack
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

@Composable
fun SpectrogramVisualizer(
    isPlaying: Boolean,
    currentTrack: AnalyzedTrack?,
    modifier: Modifier = Modifier
) {
    val barCount = 24
    val barHeights = remember { mutableStateListOf(*Array(barCount) { 0.08f }) }
    val peakCaps = remember { mutableStateListOf(*Array(barCount) { 0.08f }) }

    // Left and Right simulated dynamic stereo VU meters
    var leftVuLevel by remember { mutableFloatStateOf(0.1f) }
    var rightVuLevel by remember { mutableFloatStateOf(0.1f) }
    var dynamicPeakDb by remember { mutableFloatStateOf(-18.0f) }

    val animatedLeftVu by animateFloatAsState(targetValue = leftVuLevel, label = "leftVu")
    val animatedRightVu by animateFloatAsState(targetValue = rightVuLevel, label = "rightVu")

    LaunchedEffect(isPlaying, currentTrack) {
        if (isPlaying) {
            val rand = Random(System.currentTimeMillis())
            while (isActive) {
                val bassFactor = currentTrack?.bassDensity?.toFloat() ?: 0.5f
                val vocalFactor = currentTrack?.vocalPresence?.toFloat() ?: 0.5f

                // Update 24 frequency bars and peak caps
                for (i in 0 until barCount) {
                    val bias = when {
                        i < 7 -> bassFactor * 1.15f
                        i in 7..15 -> vocalFactor * 1.05f
                        else -> 0.42f
                    }

                    val rawTarget = (bias * 0.60f + rand.nextFloat() * 0.40f).coerceIn(0.08f, 0.98f)
                    // Smooth decay & attack
                    barHeights[i] = (barHeights[i] + (rawTarget - barHeights[i]) * 0.55f).coerceIn(0.05f, 1.0f)

                    // Physics for peak hold caps (instant rise, gradual gravity fall)
                    if (barHeights[i] > peakCaps[i]) {
                        peakCaps[i] = barHeights[i]
                    } else {
                        peakCaps[i] = max(0.05f, peakCaps[i] - 0.025f)
                    }
                }

                // Calculate stereo VU energy
                val avgEnergy = barHeights.average().toFloat()
                val leftTarget = (avgEnergy * 1.1f + (rand.nextFloat() - 0.5f) * 0.12f).coerceIn(0.05f, 0.95f)
                val rightTarget = (avgEnergy * 1.1f + (rand.nextFloat() - 0.5f) * 0.12f).coerceIn(0.05f, 0.95f)
                leftVuLevel = leftTarget
                rightVuLevel = rightTarget

                // Peak dB calculation
                val currentMax = barHeights.maxOrNull() ?: 0.1f
                dynamicPeakDb = (-24f + currentMax * 23.8f).coerceIn(-24f, -0.2f)

                delay(50)
            }
        } else {
            // Smooth idle state
            for (i in 0 until barCount) {
                barHeights[i] = 0.06f
                peakCaps[i] = 0.06f
            }
            leftVuLevel = 0.05f
            rightVuLevel = 0.05f
            dynamicPeakDb = -24.0f
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF14171E))
            .border(1.dp, Color(0xFF222633), RoundedCornerShape(14.dp))
            .padding(12.dp)
            .testTag("spectrogram_visualizer")
    ) {
        // Top telemetry header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = if (isPlaying) Color(0xFF00F5D4) else Color(0xFF515970),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "REAL-TIME SPECTROGRAM & VU",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            // Realtime dB peak badge
            Text(
                text = String.format(Locale.US, "PEAK: %.1f dBFS", dynamicPeakDb),
                color = if (dynamicPeakDb > -3f) Color(0xFFFF5252) else Color(0xFF00F5D4),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main Visualizer Row with Stereo VU Meters and Spectrum Bars
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Left (L) VU Channel Meter
            VuChannelBar(
                channelLabel = "L",
                levelFraction = animatedLeftVu
            )

            // Center: 24 Spectrum Neon Bars with peak caps
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.BottomCenter
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    for (i in 0 until barCount) {
                        val heightFraction = barHeights[i].coerceIn(0.05f, 1.0f)
                        val capFraction = peakCaps[i].coerceIn(0.05f, 1.0f)

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            // Active Neon Jumping Bar
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(heightFraction)
                                    .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp))
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color(0xFF00F5D4),
                                                Color(0xFF00B4D8).copy(alpha = 0.7f),
                                                Color(0xFF1C202B).copy(alpha = 0.3f)
                                            )
                                        )
                                    )
                            )

                            // Peak Hold Cap floating above
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(capFraction)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopCenter)
                                        .fillMaxWidth()
                                        .height(2.dp)
                                        .background(
                                            if (capFraction > 0.85f) Color(0xFFFF5252) else Color(0xFFE0AAFF)
                                        )
                                )
                            }
                        }
                    }
                }
            }

            // Right (R) VU Channel Meter
            VuChannelBar(
                channelLabel = "R",
                levelFraction = animatedRightVu
            )
        }
    }
}

@Composable
private fun VuChannelBar(
    channelLabel: String,
    levelFraction: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.width(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(8.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF0C0E12))
                .border(0.5.dp, Color(0xFF222633), RoundedCornerShape(3.dp)),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(levelFraction.coerceIn(0.05f, 1.0f))
                    .clip(RoundedCornerShape(3.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color(0xFFFF5252),  // Red 0dB
                                0.25f to Color(0xFFFFB703), // Amber -6dB
                                0.65f to Color(0xFF39FF14), // Green -12dB
                                1.0f to Color(0xFF00F5D4)   // Teal base
                            )
                        )
                    )
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = channelLabel,
            color = Color(0xFF8E95A5),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
