<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/534cb6e3-efa8-497b-b684-d8adf7617aa1

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Run the app on an emulator or physical device (`Run ▶`), or build an APK directly via `Build > Build Bundle(s)/APK(s) > Build APK(s)`.
5. The app doesn't call the Gemini API or Firebase, so no `.env` file or `google-services.json` is required. If you add Gemini/Firebase features later, set `GEMINI_API_KEY` in a `.env` file (see `.env.example`) and re-add the Firebase dependencies/plugin in `app/build.gradle.kts`.
6. `applicationId` has been set to `com.example.aimasterplayer` — change it to your own before publishing.
7. Release builds sign with the debug key by default (so `assembleRelease` works out of the box). Before publishing to Google Play, put a real upload keystore at `my-upload-key.jks` (or set the `KEYSTORE_PATH`/`STORE_PASSWORD`/`KEY_PASSWORD` env vars) — the build will then automatically switch to it.
8. If you have already published this app in AI Studio under the old package name, please [request an upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Building an APK automatically with GitHub Actions

This project includes `.github/workflows/build-apk.yml`. Push this project to a GitHub repository and it will automatically build both a debug and a release APK on every push to `main`/`master` (or run it manually from the **Actions** tab → **Build APK** → **Run workflow**).

Once the run finishes, open it and download the APK from the **Artifacts** section at the bottom of the run page (`app-debug-apk` / `app-release-apk`, as a `.zip` containing the `.apk`).

To sign the release APK with your own upload key instead of the debug key, add these as **Repository secrets** (Settings → Secrets and variables → Actions):
- `STORE_PASSWORD`, `KEY_PASSWORD` — your keystore/key passwords
- `KEYSTORE_PATH` — only needed if you also commit/provide the `.jks` file at that path in the runner; otherwise leave the release build signed with the debug key for testing.
